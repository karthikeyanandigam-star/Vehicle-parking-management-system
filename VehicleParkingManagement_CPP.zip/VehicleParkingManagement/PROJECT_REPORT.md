# PROJECT REPORT
## Vehicle Parking Management System using C++

### 1. Abstract
The Vehicle Parking Management System is a console-based C++ application designed to organize vehicle parking in a small parking facility. It assigns an available slot to a car or bike, records entry details, supports vehicle search and exit, calculates parking charges, and maintains active parking data and an activity history using files.

### 2. Problem Statement
Manual parking management can cause confusion about available slots, vehicle location, and parking duration. This project provides a simple computerized solution that maintains slot status and vehicle records.

### 3. Objectives
- Automate vehicle entry and slot allocation.
- Maintain accurate active parking information.
- Search vehicles using registration number.
- Calculate parking charges during exit.
- Preserve active parking records between program runs.
- Demonstrate core C++ and OOP concepts.

### 4. Scope
The prototype supports ten parking slots and two vehicle types: cars and bikes. It is intended for academic demonstration and can be extended with a GUI, database, authentication, and payment integration.

### 5. System Design
**Vehicle (abstract base class)** stores registration number, owner, type, slot, and entry time. It defines virtual methods for hourly rate and display.

**Car and Bike (derived classes)** implement their respective hourly parking rates.

**ParkingLot** manages slots and parked vehicle objects, validates entry, searches vehicles, processes exit and billing, and handles data/history files.

### 6. Functional Modules
1. Vehicle Parking / Entry
2. Vehicle Exit and Billing
3. Vehicle Search
4. Parked Vehicle Listing
5. Slot Availability
6. Parking History
7. File Persistence

### 7. Algorithm (Vehicle Entry)
1. Check whether a free slot exists.
2. Read registration number, owner name, and type.
3. Validate required fields and vehicle type.
4. Reject a duplicate active registration number.
5. Create a Car or Bike object.
6. Assign the first free slot and current entry time.
7. Update slot status and save active data.
8. Append an entry event to history.

### 8. Algorithm (Vehicle Exit)
1. Read registration number.
2. Search active parking records.
3. If not found, show an error.
4. Calculate elapsed time from entry to current time.
5. Round partial hours upward and apply the vehicle rate.
6. Display bill and append exit event.
7. Release the slot, remove the active vehicle, and save data.

### 9. Parking Rates
| Vehicle | Rate |
|---|---:|
| Car | ₹30/hour |
| Bike | ₹15/hour |

A minimum of one hour is billed; partial hours are rounded up. These are sample rates for demonstration.

### 10. C++ Concepts Used
- Classes and objects
- Encapsulation
- Constructors and destructors
- Inheritance
- Abstract class and pure virtual function
- Runtime polymorphism / overriding
- STL vector and algorithms
- File handling
- Functions, loops, switch-case
- Pointers and dynamic memory management
- Input validation

### 11. Test Cases
| Test | Input/Action | Expected Result |
|---|---|---|
| 1 | Park a car | First free slot assigned |
| 2 | Park a bike | Next free slot assigned |
| 3 | Repeat active vehicle number | Duplicate rejected |
| 4 | Search valid number | Vehicle details displayed |
| 5 | Search invalid number | Not found message |
| 6 | Exit valid vehicle | Bill shown and slot released |
| 7 | Exit unknown vehicle | Not found message |
| 8 | Fill all 10 slots | Parking full message |
| 9 | Restart application | Active vehicles restored |
| 10 | View history | Entry/exit events displayed |

### 12. Limitations
- Console interface only.
- Ten fixed slots.
- Sample hourly rates.
- Text files are used instead of a database.
- No real payment gateway or security/authentication.

### 13. Future Enhancements
- GUI interface
- Admin login and reports
- Different slot sizes and vehicle categories
- Monthly passes and reservations
- Database integration
- QR tickets and payment integration

### 14. Conclusion
The project demonstrates how C++ object-oriented programming and file handling can be used to solve a practical parking-management problem. It automates basic parking operations and provides a foundation for future improvements.
