# Vehicle Parking Management System (C++)

A console-based Vehicle Parking Management System built using **C++ only**. It demonstrates object-oriented programming, inheritance, runtime polymorphism, STL vectors, file handling, and menu-driven control.

## Features
- Park cars and bikes in automatically assigned slots (10 slots).
- Prevent duplicate vehicle numbers and reject parking when full.
- Search parked vehicles by registration number.
- Vehicle exit with hourly billing (minimum 1 hour, rounded up).
- Display occupied/available slots and currently parked vehicles.
- Persist active parking data in `parking_data.txt`.
- Append entry/exit activity to `parking_history.txt`.

## Requirements
- C++ compiler supporting C++11 or newer (GCC/MinGW recommended).
- Windows, Linux, or macOS terminal.

## Compile and run
### Windows (MinGW g++)
```bash
g++ -std=c++11 -Wall -Wextra main.cpp -o parking.exe
parking.exe
```
### Linux/macOS
```bash
g++ -std=c++11 -Wall -Wextra main.cpp -o parking
./parking
```

The data/history text files are created automatically in the current working directory.

## Menu
1. Park a vehicle
2. Vehicle exit & billing
3. Search vehicle
4. View parked vehicles
5. View parking slots
6. View parking history
0. Exit

## Rates (demo values)
- Car: ₹30 per hour
- Bike: ₹15 per hour

Billing uses elapsed time since entry, rounds partial hours upward, and charges at least one hour.

## C++ concepts
- Classes and objects: `Vehicle`, `Car`, `Bike`, `ParkingLot`
- Encapsulation: vehicle attributes are protected/private and exposed through methods
- Inheritance: `Car` and `Bike` derive from `Vehicle`
- Runtime polymorphism: virtual `hourlyRate()` and `display()`
- STL: `vector`, algorithms (`count`, `transform`)
- File handling: `ifstream`, `ofstream`
- Functions, loops, switch-case, input validation, pointers, constructors/destructors

## Important
This is an educational prototype, not a production parking/payment system. Rates and slot count can be changed in `main.cpp`.
