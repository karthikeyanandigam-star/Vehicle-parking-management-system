#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <iomanip>
#include <ctime>
#include <algorithm>
#include <limits>

using namespace std;

const int TOTAL_SLOTS = 10;
const double CAR_RATE = 30.0;   // per hour
const double BIKE_RATE = 15.0; // per hour

string currentTime() {
    time_t now = time(nullptr);
    tm *local = localtime(&now);
    char buffer[32];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", local);
    return buffer;
}

class Vehicle {
protected:
    string number, owner, type;
    int slot;
    string entryTime;
public:
    Vehicle(string n="", string o="", string t="", int s=0, string e="") :
        number(n), owner(o), type(t), slot(s), entryTime(e) {}
    virtual ~Vehicle() = default;
    virtual double hourlyRate() const = 0;
    string getNumber() const { return number; }
    string getOwner() const { return owner; }
    string getType() const { return type; }
    int getSlot() const { return slot; }
    string getEntryTime() const { return entryTime; }
    virtual void display() const {
        cout << left << setw(14) << number << setw(18) << owner
             << setw(10) << type << setw(8) << slot << entryTime << '\n';
    }
};

class Car : public Vehicle {
public:
    Car(string n, string o, int s, string e) : Vehicle(n,o,"Car",s,e) {}
    double hourlyRate() const override { return CAR_RATE; }
};
class Bike : public Vehicle {
public:
    Bike(string n, string o, int s, string e) : Vehicle(n,o,"Bike",s,e) {}
    double hourlyRate() const override { return BIKE_RATE; }
};

class ParkingLot {
    vector<Vehicle*> parked;
    vector<bool> occupied;
    const string dataFile = "parking_data.txt";
    const string historyFile = "parking_history.txt";

    int findFreeSlot() const {
        for (int i=0; i<TOTAL_SLOTS; ++i) if (!occupied[i]) return i+1;
        return -1;
    }
    int findVehicleIndex(const string& number) const {
        for (size_t i=0; i<parked.size(); ++i)
            if (parked[i]->getNumber()==number) return static_cast<int>(i);
        return -1;
    }
    void saveData() const {
        ofstream out(dataFile);
        for (const auto *v : parked)
            out << v->getType() << '|' << v->getNumber() << '|'
                << v->getOwner() << '|' << v->getSlot() << '|'
                << v->getEntryTime() << '\n';
    }
    void logHistory(const string& text) const {
        ofstream out(historyFile, ios::app);
        out << currentTime() << " | " << text << '\n';
    }
    void loadData() {
        ifstream in(dataFile);
        string line;
        while (getline(in,line)) {
            vector<string> p; size_t start=0, pos;
            while ((pos=line.find('|',start))!=string::npos) {
                p.push_back(line.substr(start,pos-start)); start=pos+1;
            }
            p.push_back(line.substr(start));
            if (p.size()!=5) continue;
            try {
                int slot=stoi(p[3]);
                if(slot<1 || slot>TOTAL_SLOTS || occupied[slot-1]) continue;
                Vehicle *v=nullptr;
                if(p[0]=="Car") v=new Car(p[1],p[2],slot,p[4]);
                else if(p[0]=="Bike") v=new Bike(p[1],p[2],slot,p[4]);
                if(v) { parked.push_back(v); occupied[slot-1]=true; }
            } catch (...) { /* ignore malformed saved row */ }
        }
    }
public:
    ParkingLot() : occupied(TOTAL_SLOTS,false) { loadData(); }
    ~ParkingLot() { for(auto *v:parked) delete v; }

    void showSlots() const {
        cout << "\n--- PARKING SLOT STATUS ---\n";
        for(int i=0;i<TOTAL_SLOTS;++i)
            cout << "Slot " << setw(2) << i+1 << " : "
                 << (occupied[i] ? "OCCUPIED" : "AVAILABLE") << '\n';
        cout << "Available: " << count(occupied.begin(),occupied.end(),false)
             << "/" << TOTAL_SLOTS << "\n";
    }
    void parkVehicle() {
        if(findFreeSlot()==-1) { cout << "\nParking is full!\n"; return; }
        string number,owner,type;
        cout << "Vehicle number (e.g. AP01AB1234): "; getline(cin,number);
        cout << "Owner name: "; getline(cin,owner);
        cout << "Vehicle type (car/bike): "; getline(cin,type);
        transform(type.begin(),type.end(),type.begin(),[](unsigned char c){return char(tolower(c));});
        if(number.empty() || owner.empty()) { cout<<"Number and owner cannot be empty.\n"; return; }
        if(findVehicleIndex(number)!=-1) { cout<<"This vehicle is already parked.\n"; return; }
        int slot=findFreeSlot(); string entry=currentTime(); Vehicle *v=nullptr;
        if(type=="car") v=new Car(number,owner,slot,entry);
        else if(type=="bike") v=new Bike(number,owner,slot,entry);
        else { cout<<"Invalid type. Enter car or bike.\n"; return; }
        parked.push_back(v); occupied[slot-1]=true; saveData();
        logHistory("ENTRY: "+number+" ("+type+") assigned slot "+to_string(slot));
        cout<<"\nVehicle parked successfully!\nAssigned slot: "<<slot
            <<"\nEntry time: "<<entry<<"\nHourly rate: Rs. "<<v->hourlyRate()<<"\n";
    }
    void exitVehicle() {
        string number; cout<<"Enter vehicle number: "; getline(cin,number);
        int idx=findVehicleIndex(number);
        if(idx==-1) { cout<<"Vehicle not found in parking.\n"; return; }
        Vehicle *v=parked[idx];
        // A simple demonstration billing rule: minimum one hour, rounded up.
        time_t now=time(nullptr); tm entryTm={};
        // Parse saved timestamp using local time format.
        int y,mo,d,h,mi,se;
        if(sscanf(v->getEntryTime().c_str(),"%d-%d-%d %d:%d:%d",&y,&mo,&d,&h,&mi,&se)==6) {
            entryTm.tm_year=y-1900; entryTm.tm_mon=mo-1; entryTm.tm_mday=d;
            entryTm.tm_hour=h; entryTm.tm_min=mi; entryTm.tm_sec=se;
            time_t entryEpoch=mktime(&entryTm);
            long seconds=static_cast<long>(difftime(now,entryEpoch));
            int hours=max(1,static_cast<int>((max(0L,seconds)+3599)/3600));
            double fee=hours*v->hourlyRate();
            cout<<"\n--- PARKING BILL ---\nVehicle: "<<v->getNumber()
                <<"\nType: "<<v->getType()<<"\nSlot: "<<v->getSlot()
                <<"\nEntry: "<<v->getEntryTime()<<"\nExit: "<<currentTime()
                <<"\nBillable hours: "<<hours<<"\nAmount: Rs. "<<fixed<<setprecision(2)<<fee<<"\n";
            logHistory("EXIT: "+number+" | "+to_string(hours)+" hour(s) | Rs. "+to_string(fee));
        }
        occupied[v->getSlot()-1]=false; delete v;
        parked.erase(parked.begin()+idx); saveData();
        cout<<"Vehicle exited. Slot "<<(idx>=0? "released":"")<<".\n";
    }
    void searchVehicle() const {
        string number; cout<<"Enter vehicle number: "; getline(cin,number);
        int idx=findVehicleIndex(number);
        if(idx==-1) cout<<"Vehicle not found.\n";
        else { cout<<"\nVehicle found:\n"; parked[idx]->display(); }
    }
    void showParkedVehicles() const {
        cout<<"\n--- PARKED VEHICLES ---\n";
        if(parked.empty()) { cout<<"No vehicles currently parked.\n"; return; }
        cout<<left<<setw(14)<<"Number"<<setw(18)<<"Owner"<<setw(10)<<"Type"
            <<setw(8)<<"Slot"<<"Entry time\n";
        cout<<string(65,'-')<<'\n';
        for(const auto *v:parked) v->display();
    }
    void showHistory() const {
        ifstream in(historyFile); string line;
        cout<<"\n--- PARKING HISTORY ---\n";
        if(!in) { cout<<"No history available yet.\n"; return; }
        while(getline(in,line)) cout<<line<<'\n';
    }
};

void showMenu() {
    cout<<"\n========================================\n"
        <<"     VEHICLE PARKING MANAGEMENT SYSTEM\n"
        <<"========================================\n"
        <<"1. Park a vehicle\n"
        <<"2. Vehicle exit & billing\n"
        <<"3. Search vehicle\n"
        <<"4. View parked vehicles\n"
        <<"5. View parking slots\n"
        <<"6. View parking history\n"
        <<"0. Exit\n"
        <<"----------------------------------------\n"
        <<"Enter choice: ";
}

int main() {
    ParkingLot lot;
    int choice;
    cout<<"Welcome! Parking data is loaded from file.\n";
    do {
        showMenu();
        if(!(cin>>choice)) {
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Please enter a valid number.\n"; continue;
        }
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
        switch(choice) {
            case 1: lot.parkVehicle(); break;
            case 2: lot.exitVehicle(); break;
            case 3: lot.searchVehicle(); break;
            case 4: lot.showParkedVehicles(); break;
            case 5: lot.showSlots(); break;
            case 6: lot.showHistory(); break;
            case 0: cout<<"Thank you for using the system!\n"; break;
            default: cout<<"Invalid choice. Try again.\n";
        }
    } while(choice!=0);
    return 0;
}
